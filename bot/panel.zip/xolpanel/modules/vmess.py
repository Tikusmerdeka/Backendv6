from kyt import *
import subprocess, asyncio
from telethon import Button, events
#CRATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
  async def create_vmess_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    async with bot.conversation(chat) as pw:
      await event.respond("**Limit Quota :**")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    async with bot.conversation(chat) as exp:
      await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 7 Day •","7"),
Button.inline("• 15 Day •","15")],
[Button.inline("• 30 Day •","30"),
Button.inline("• 60 Day •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`Processing Crate Premium Account`")
    await asyncio.sleep(1)

    for i in range(4):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 1) + "▱" * ((3 - i) // 1)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" "{exp}" "{ip}" "{pw}" | /etc/shell/2'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Already Exist**")
    else:
      today = DT.date.today()
      later = today + DT.timedelta(days=int(exp))
      b = [x.group() for x in re.finditer("vmess://(.*)",a)]
      print(b)
      uuid = re.search("vmess://(.*?)#",b[3]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**           ◇ VMESS ACCOUNT ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Remarks      :** `{user}`
**» Host Domain  :** `{DOMAIN}`
**» User ID      :** `{uuid}`
**» Limit IP :** `{ip} IP`
**» Port TLS     :** `443`
**» Port NTLS    :** `80`
**» Port GRPC    :** `443`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path         :** `/vmess`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `vmess-grpc`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link TLS     :** 
`{b[0].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link NTLS    :** 
`{b[1].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link GRPC    :** 
`{b[2].strip("'")}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link Account     :**
https://{DOMAIN}:81/vmess-{user}.txt
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Expired Until :** `{later}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹🔹Main Menu🔹›","vmess")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await create_vmess_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
  async def trial_vmess_(event):
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    await event.edit("`Processing Crate Triall Account`")
    await asyncio.sleep(1)

    for i in range(4):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 1) + "▱" * ((3 - i) // 1)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "${ip}" | /etc/shell/7'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Already Exist**")
    else:
      b = [x.group() for x in re.finditer("vmess://(.*)",a)]
      print(b)
      remarks = re.search("#(.*)",b[3]).group(1)
      uuid = re.search("vmess://(.*?)#",b[3]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**      ◇ TRIAL VMESS ACCOUNT ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Remarks      :** `{remarks}`
**» Host Domain  :** `{DOMAIN}`
**» User ID      :** `{uuid}`
**» Limit IP :** `{ip} IP`
**» port TLS     :** `443`
**» Port NTLS    :** `80`
**» Port GRPC    :** `443`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path         :** `/vmess`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `vmess-grpc`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link TLS     :** 
`{b[0].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link NTLS    :** 
`{b[1].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link GRPC    :** 
`{b[2].strip("'")}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link Account     :**
https://{DOMAIN}:81/vmess-{remarks}.txt
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Expired Until :** `1 Hour`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹🔹Main Menu🔹›","vmess")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await trial_vmess_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
  async def cek_vmess_(event):
    cmd = '/etc/shell/cek vmess'.strip()
    x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    print(x)
    z = subprocess.check_output(cmd, shell=True).decode("utf-8")
    await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**      ◇ List Vmess Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
{z}
**◇━━━━━━━━━━━━━━━━━━━━━◇**
""",buttons=[[Button.inline("‹🔹Main Menu🔹›","vmess")]])
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await cek_vmess_(event)
  else:
    await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'login-vmess'))
async def login_vmess(event):
  async def login_vmess_(event):
    cmd = '/etc/shell/loginx vmess'.strip()
    x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    print(x)
    z = subprocess.check_output(cmd, shell=True).decode("utf-8")
    await event.respond(f"""

{z}
**◇━━━━━━━━━━━━━━━━━━━━━◇**
""",buttons=[[Button.inline("‹🔹Main Menu🔹›","vmess")]])
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await login_vmess_(event)
  else:
    await event.answer("Access Denied",alert=True) 

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
  async def delete_vmess_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    await event.edit("`Processing Deleted Premium Account`")
    await asyncio.sleep(1)

    for i in range(4):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 1) + "▱" * ((3 - i) // 1)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" | /etc/shell/del vmess'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Not Found**")
    else:
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
** ◇ Succes Delete Vmess Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» User :** `{user}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹🔹Main Menu🔹›","vmess")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await delete_vmess_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-vmess'))
async def ren_vmess(event):
  async def ren_vmess_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    async with bot.conversation(chat) as pw:
      await event.respond("**Limit Quota :**")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    async with bot.conversation(chat) as exp:
      await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 7 Day •","7"),
Button.inline("• 15 Day •","15")],
[Button.inline("• 30 Day •","30"),
Button.inline("• 60 Day •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`Processing Update Premium Account`")
    await asyncio.sleep(1)

    for i in range(4):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 1) + "▱" * ((3 - i) // 1)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{ip}" | /etc/shell/ren vmess'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Not Found**")
    else:
      x = [x.group() for x in re.finditer("exp://(.*)",a)]
      print(x)
      exp1 = re.search("exp://(.*?)@",x[0]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**  ◇ Succes Renew Vmess Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» User :** `{user}`
**» Quota :** `{pw}`
**» IP :** `{ip}`
**» Expired On :** `{exp1}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹🔹Main Menu🔹›","vmess")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_vmess_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)
    
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
  async def vmess_(event):
    inline = [
[Button.inline(" CREATE VMESS ","create-vmess"),
Button.inline(" TRIAL VMESS ","trial-vmess")],
[Button.inline(" DELETE VMESS ","delete-vmess"),
Button.inline(" RENEW VMESS ","renew-vmess")],
[Button.inline(" CHECK VMESS ","cek-vmess"),
Button.inline(" LOGIN VMESS ","login-vmess")],
[Button.inline("‹ 🔹Main Menu🔹 ›","menu")]]
    z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**     🧿 VMESS MANAGER 🧿**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Service   :** `VMESS`
**» Domain   :** `{DOMAIN}`
**» ISP VPS  :** `{z["isp"]}`
**» Country  :** `{z["country"]}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await vmess_(event)
  else:
    await event.answer("Access Denied",alert=True)
