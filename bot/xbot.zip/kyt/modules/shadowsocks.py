from xolpanel import *
import subprocess, asyncio
from telethon import Button, events
@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
  async def create_shadowsocks_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    async with bot.conversation(chat) as pw:
      await event.respond("**Limit Quota :**")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    async with bot.conversation(chat) as exp:
      await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 7 Day •","7"),
Button.inline("• 15 Day •","15")],
[Button.inline("• 30 Day •","30"),
Button.inline("• 60 Day •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`Processing Crate Premium Account`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" "{exp}" "{ip}" "{pw}" | /etc/shell/5'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Already Exist**")
    else:
      today = DT.date.today()
      later = today + DT.timedelta(days=int(exp))
      x = [x.group() for x in re.finditer("ss://(.*)",a)]
      print(x)
      uuid = re.search("ss://chacha20-ietf-poly1305:(.*?)@",x[0]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**     ◇ Shadowsocks Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Remarks      :** `{user}`
**» Host Server  :** `{DOMAIN}`
**» User Quota   :** `{pw} GB`
**» Limit Adress :** `{ip} IP`
**» Port TLS     :** `443`
**» Port NTLS    :** `80`
**» Port GRPC    :** `443`
**» Password     :** `{uuid}`
**» Cipers       :** `chacha20-ietf-poly1305`
**» NetWork      :** `(WS) or (gRPC)`
**» Path         :** `(/shadowsocks)`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `shadowsocks-grpc`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link Account :**
**https://{DOMAIN}:81/ss-{user}.txt**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Expired Until :** `{later}`
**» 🤖@fonetunnel**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await create_shadowsocks_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
  async def cek_shadowsocks_(event):
    cmd = '/etc/shell/cek ss'.strip()
    x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    print(x)
    z = subprocess.check_output(cmd, shell=True).decode("utf-8")
    await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**      ◇ List S_Socks Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
{z}
**» 🤖@fonetunnel**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
""",buttons=[[Button.inline("‹ Main Menu ›","shadowsocks")]])
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await cek_shadowsocks_(event)
  else:
    await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'login-shadowsocks'))
async def login_shadowsocks(event):
  async def login_shadowsocks_(event):
    cmd = '/etc/shell/loginx ss'.strip()
    x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    print(x)
    z = subprocess.check_output(cmd, shell=True).decode("utf-8")
    await event.respond(f"""

{z}
**» 🤖@undersTnl**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
""",buttons=[[Button.inline("‹ Main Menu ›","shadowsocks")]])
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await login_shadowsocks_(event)
  else:
    await event.answer("Access Denied",alert=True) 

@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
  async def delete_shadowsocks_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    await event.edit("`Processing Deleted Premium Account`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" | /etc/shell/del ss'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Not Found**")
    else:
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
** ◇ Succes Delete S_Socks Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**» User :** `{user}`
**» 🤖@fonetunnel**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await delete_shadowsocks_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-shadowsocks'))
async def ren_shadowsocks(event):
  async def ren_shadowsocks_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    async with bot.conversation(chat) as pw:
      await event.respond("**Limit Quota :**")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    async with bot.conversation(chat) as exp:
      await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 7 Day •","7"),
Button.inline("• 15 Day •","15")],
[Button.inline("• 30 Day •","30"),
Button.inline("• 60 Day •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`Processing Update Premium Account`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{ip}" | /etc/shell/ren ss'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Not Found**")
    else:
      x = [x.group() for x in re.finditer("exp://(.*)",a)]
      print(x)
      exp1 = re.search("exp://(.*?)@",x[0]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
** ◇ Succes Renew S_Socks Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» User :** `{user}`
**» Quota :** `{pw}`
**» IP :** `{ip}`
**» Expired On :** `{exp1}`
**» 🤖@fonetunnel**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_shadowsocks_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)
    
@bot.on(events.CallbackQuery(data=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
  async def trial_shadowsocks_(event):
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    await event.edit("`Processing Crate Triall Account`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{ip}" | /etc/shell/10'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Already Exist**")
    else:
      x = [x.group() for x in re.finditer("ss://(.*)",a)]
      print(x)
      remarks = re.search("#(.*)",x[0]).group(1)
      uuid = re.search("ss://chacha20-ietf-poly1305:(.*?)#",x[0]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**     ◇ Shadowsocks Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Remarks      :** `{remarks}`
**» Host Server  :** `{DOMAIN}`
**» User Quota   :** `5 GB`
**» Limit Adress :** `{ip} IP`
**» Port TLS     :** `443`
**» Port NTLS    :** `80`
**» Port GRPC    :** `443`
**» Password     :** `{uuid}`
**» Cipers       :** `chacha20-ietf-poly1305`
**» NetWork      :** `(WS) or (gRPC)`
**» Path         :** `(/shadowsocks)`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `shadowsocks-grpc`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link Account :**
**https://{DOMAIN}:81/ss-{remarks}.tx**`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Expired Until :** `1 Day`
**» 🤖@fonetunnel**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await trial_shadowsocks_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
  async def shadowsocks_(event):
    inline = [
[Button.inline(" Create S_Socks ","create-shadowsocks"),
Button.inline(" Triall S_Socks ","trial-shadowsocks")],
[Button.inline(" Delete S_Socks ","delete-shadowsocks"),
Button.inline(" Renew S_Socks ","renew-shadowsocks")],
[Button.inline(" Check S_Socks ","cek-shadowsocks"),
Button.inline(" Login S_Socks ","login-shadowsocks")],
[Button.inline("‹ Main Menu ›","menu")]]
    z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**         ☘️ S_SOCKS MANAGER ☘️**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Service   :** `SHADOWSOCKS`
**» Domain   :** `{DOMAIN}`
**» ISP VPS  :** `{z["isp"]}`
**» Country  :** `{z["country"]}`
**» 🤖@fonetunnel**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await shadowsocks_(event)
  else:
    await event.answer("Access Denied",alert=True)
